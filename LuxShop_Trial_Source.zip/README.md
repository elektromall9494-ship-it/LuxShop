# LuxShop — offline sınaq
Bu, real onlayn mağaza deyil. Məhsullar, səbət, profil və sınaq sifarişləri yalnız cihazın lokal yaddaşında saxlanır. Tətbiq silindikdə məlumatlar itə bilər. Real SMS, Google hesabı, push, server stok nəzarəti və kart ödənişi bu versiyada yoxdur. Admin düyməsi açıqdır, yalnız prototip üçündür.

Android: bu qovluğun İÇİNDƏKİ faylları ayrıca yeni GitHub deposuna yerləşdirin (.github/workflows/build.yml daxil). Actions → LuxShop Trial APK → Run workflow. Yaşıl nəticənin Artifacts bölməsindən APK ZIP endirilir, açılıb APK quraşdırılır.

Kompüter və mobil brauzer: app/src/main/assets/index.html açın. iPhone üçün bu yalnız brauzer prototipidir; native iOS tətbiqi və App Store yayımı hazırlanmayıb.

Admin: Hesabım → Sınaq admini → Məhsul əlavə et. İlk katalog boşdur. Şəkillər cihazda ölçüsü kiçildilərək saxlanır. AZ/EN/RU interfeys dilləri var; məhsul adının digər dillərini admin daxil edir.

0.2 yeniləmə: güc, kelvin, satış vahidi, bağlama məlumatı, kateqoriyaya uyğun redaktə edilən açıqlama şablonları, böyük şəkil və Android paylaşma menyusu. Paylaşım şəkil və mətndir; işlək onlayn məhsul linki yoxdur. Stok və sifarişlər cihazdadır. Google girişi və avtomatik bildirişlər növbəti onlayn mərhələyə aiddir.
GitHub-da mənbə ZIP-in adını LuxShop_Trial_Source.zip saxlayın. Workflow həmin ZIP-i luxshop qovluğuna açıb assembleDebug işlədir. Yeni APK köhnənin üzərinə quraşdırılmazsa debug imzası fərqli ola bilər. Silib yenidən quraşdırmaq lokal sınaq məlumatlarını itirər.
